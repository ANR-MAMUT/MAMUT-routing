"""ExternalSolver end to end with the fake executable: inputs, scaling, outputs, failures, provenance."""

from __future__ import annotations

import hashlib
import json
import os
import sys
import threading
from pathlib import Path

import pytest

from mamut_routing_lib.enums import ObjectiveFunction, ProblemType
from mamut_routing_lib.solvers import InstanceNotSupportedError, get_solver, run_solver, solver_names
from mamut_routing_lib.solvers.base import SolveMonitor, SolverCapabilities
from mamut_routing_lib.solvers.external.adapter import ExternalSolver
from mamut_routing_lib.solvers.external.catalog import BUILTIN_DESCRIPTORS
from mamut_routing_lib.solvers.external.descriptor import ExternalSolverDescriptor

pytestmark = pytest.mark.skipif(sys.platform == "win32", reason="POSIX process groups")

FAKE = ("{python}", "-m", "mamut_routing_lib.solvers.external._fake_solver")
CVRP_MONO = {ProblemType.CVRP: frozenset({ObjectiveFunction.MONO_COST})}

FAKE_X = ExternalSolverDescriptor(
    name="fake-x",
    label="FakeX",
    method="fake-x",
    argv=(*FAKE, "--problem", "{problem}", "--solution", "{solution}", "--seed", "{seed}", "--time-limit", "{time_limit_s}"),
    input_format="cvrplib-x",
    output_format="cvrplib-sol",
    capabilities=SolverCapabilities(objectives=CVRP_MONO, input="coordinates", symmetric_only=True, fleet_limit=False),
    runtime="python",
    distance_model="float",
    coordinate_scales=(1.0,),
    progress_pattern=r"progress cost=(?P<cost>[0-9.]+)",
    env={"FAKE_DISTANCE": "float"},
    timeout_grace_s=0.3,
    timeout_grace_fraction=0.0,
    term_grace_s=0.3,
)

FAKE_LKH = ExternalSolverDescriptor(
    name="fake-lkh",
    label="FakeLKH",
    method="fake-lkh",
    argv=(*FAKE, "--params", "{params}"),
    input_format="lkh",
    output_format="lkh-mtsp",
    capabilities=SolverCapabilities(
        objectives={
            ProblemType.CVRP: frozenset({ObjectiveFunction.MONO_COST}),
            ProblemType.VRPTW: frozenset({ObjectiveFunction.MONO_COST}),
        },
        input="explicit",
        integer_costs=True,
    ),
    runtime="python",
    distance_model="integer",
    timeout_grace_s=0.3,
    timeout_grace_fraction=0.0,
    term_grace_s=0.3,
)


def _env(monkeypatch, **values: str) -> None:
    for key, value in values.items():
        monkeypatch.setenv(key, value)


def _write(instance, tmp_path: Path, name: str | None = None) -> Path:
    path = tmp_path / f"{name or instance.instance_name}.vrp.json"
    path.write_text(json.dumps(instance.model_dump(mode="json")), encoding="utf-8")
    return path


@pytest.fixture
def collection(tmp_path: Path) -> Path:
    from collection_utils import write_toy_collection

    return write_toy_collection(tmp_path)


def _variant(root: Path, problem: str, metric: str) -> Path:
    return next((root / "Poryos2026" / problem / metric).rglob("*.vrp.json"))


def test_coordinate_solver_on_a_euclidean_collection_instance(collection: Path) -> None:
    solved = run_solver(ExternalSolver(FAKE_X), _variant(collection, "CVRP", "euclidean"), time_limit_s=5, seed=4)
    result = solved.result
    assert result.status == "feasible" and solved.valid
    assert result.solver == "fake-x"
    assert result.solver_report["encoding"] == "decimal-text"
    assert "reported_cost_matches_exported_model" not in result.provenance
    assert "cost_exact" not in result.to_json()
    assert result.provenance["scale"]["mode"] == "coordinates"
    assert result.solver_cost == pytest.approx(solved.cost, abs=1e-3)
    assert result.provenance["input_sha256"] and result.provenance["argv"][0] == sys.executable
    assert "host" not in result.provenance
    assert solved.bks_metadata()["input_sha256"] == result.provenance["input_sha256"]


def test_a_python_solver_is_hashed_by_its_script_not_by_the_interpreter(collection: Path, tmp_path: Path) -> None:
    script = tmp_path / "solve.py"
    script.write_text(
        "import runpy\nrunpy.run_module('mamut_routing_lib.solvers.external._fake_solver', run_name='__main__')\n"
    )
    descriptor = FAKE_LKH.with_overrides(executable=str(script), argv=("{python}", "{executable}", "--params", "{params}"))
    solver = ExternalSolver(descriptor)
    assert solver.availability().available and solver.availability().executable == str(script)
    solved = run_solver(solver, _variant(collection, "CVRP", "fastest"), time_limit_s=5)
    assert solved.valid
    provenance = solved.result.provenance
    assert provenance["argv"][:2] == [sys.executable, str(script)]
    assert provenance["executable"] == str(script)
    assert provenance["executable_sha256"] == hashlib.sha256(script.read_bytes()).hexdigest()
    assert provenance["runtime_executable"] == sys.executable and provenance["runtime_version"]
    assert solved.bks_metadata()["executable_sha256"] == provenance["executable_sha256"]

    missing = ExternalSolver(descriptor.with_overrides(executable=str(tmp_path / "gone.py")))
    assert not missing.availability().available and "script not found" in missing.availability().reason


def test_a_python_solver_that_names_no_script_publishes_no_executable_hash(collection: Path) -> None:
    """Its argv runs a module: the interpreter's hash would say nothing about the code that ran."""
    solved = run_solver(ExternalSolver(FAKE_LKH), _variant(collection, "CVRP", "fastest"), time_limit_s=5)
    assert solved.valid
    assert solved.result.provenance["executable_sha256"] is None
    assert solved.result.provenance["runtime_executable"] == sys.executable
    assert "executable_sha256" not in solved.bks_metadata()


def test_a_java_solver_records_its_jar_and_the_jvm_that_ran_it(collection: Path, tmp_path: Path) -> None:
    jdk = tmp_path / "jdk"
    (jdk / "bin").mkdir(parents=True)
    java = jdk / "bin" / "java"  # a launcher that runs the stand-in solver, whatever the jar
    java.write_text(f'#!/bin/sh\nexec "{sys.executable}" -m mamut_routing_lib.solvers.external._fake_solver "$@"\n')
    java.chmod(0o755)
    (jdk / "release").write_text('IMPLEMENTOR="Test JDK"\nJAVA_RUNTIME_VERSION="21.0.1+12"\n')
    jar = tmp_path / "solver.jar"
    jar.write_bytes(b"the solver")
    descriptor = FAKE_LKH.with_overrides(
        runtime="java", jar=str(jar), java=str(java), argv=("{java}", "-jar", "{jar}", "--params", "{params}")
    )
    solved = run_solver(ExternalSolver(descriptor), _variant(collection, "CVRP", "fastest"), time_limit_s=5)
    assert solved.valid
    provenance = solved.result.provenance
    assert provenance["executable"] == str(jar)
    assert provenance["executable_sha256"] == hashlib.sha256(b"the solver").hexdigest()
    assert provenance["runtime_executable"] == str(java.resolve())
    assert provenance["runtime_version"] == "21.0.1+12 (Test JDK)"


def test_coordinate_solver_refuses_a_road_metric(collection: Path) -> None:
    with pytest.raises(InstanceNotSupportedError, match="coordinates"):
        run_solver(ExternalSolver(FAKE_X), _variant(collection, "CVRP", "fastest"), time_limit_s=1)


def test_lkh_style_solver_scales_exactly_and_cross_checks_its_cost(collection: Path) -> None:
    solved = run_solver(ExternalSolver(FAKE_LKH), _variant(collection, "CVRP", "fastest"), time_limit_s=5)
    result = solved.result
    assert solved.valid
    assert result.solver_report["encoding"] == "integer"
    assert result.solver_report["family_units_per_solver_unit"] == {"numerator": "1", "denominator": "4"}
    assert result.provenance["scale"]["cost_unit"] == {"numerator": "1", "denominator": "4"}
    assert result.provenance["problem_type_line"] == "CVRP"
    assert result.provenance["reported_cost_matches_exported_model"] is True
    assert result.solver_cost == pytest.approx(solved.cost)


def test_bounded_integer_search_is_priced_on_the_materialized_binary64(toy_cvrp_instance, tmp_path: Path) -> None:
    from fractions import Fraction

    from mamut_routing_lib.solvers.external.scaling import Limits

    matrix = [[0, 0.1, 1], [1, 0, 0.1], [0.1, 1, 0]]
    data = toy_cvrp_instance.model_copy(update={"arc_costs": matrix})
    path = _write(data, tmp_path)
    descriptor = FAKE_LKH.with_overrides(limits=Limits(max_arc_cost=1000))
    solved = run_solver(ExternalSolver(descriptor), path, time_limit_s=5)
    assert solved.valid
    assert solved.result.solver_report == {
        "objective": "total-arc-cost",
        "value": "3",
        "encoding": "integer",
        "family_units_per_solver_unit": {"numerator": "1", "denominator": "10"},
    }
    assert solved.result.solver_cost == 0.3
    assert solved.result.provenance["reported_cost_matches_exported_model"] is True
    assert "reported_cost_matches_exported_model" not in solved.bks_metadata()
    assert solved.result.provenance["scale"]["search_model"] == "shortest-decimal-grid"
    expected = 3 * Fraction(0.1)
    assert solved.check.exact_evaluation["authoritative_cost"] == {
        "numerator": str(expected.numerator), "denominator": str(expected.denominator),
    }
    strict = ExternalSolver(descriptor.with_overrides(require_exact_scale=True))
    with pytest.raises(InstanceNotSupportedError, match="exact binary64"):
        run_solver(strict, path, time_limit_s=5)


def test_lkh_style_solver_on_vrptw_writes_cvrptw(collection: Path) -> None:
    solved = run_solver(ExternalSolver(FAKE_LKH), _variant(collection, "VRPTW", "fastest"), time_limit_s=5)
    assert solved.valid
    assert solved.result.provenance["problem_type_line"] == "CVRPTW"


def test_asymmetric_matrix_goes_to_lkh_as_acvrp(toy_cvrp_instance, tmp_path: Path) -> None:
    asym = toy_cvrp_instance.model_copy(update={"arc_costs": [[0, 5, 6], [7, 0, 3], [6, 4, 0]]})
    solved = run_solver(ExternalSolver(FAKE_LKH), _write(asym, tmp_path), time_limit_s=5)
    assert solved.valid and solved.result.provenance["problem_type_line"] == "ACVRP"
    assert solved.result.provenance["vehicles"] >= 1


def test_symmetric_only_solver_refuses_an_asymmetric_euclidean_claim(toy_cvrp_instance, tmp_path: Path) -> None:
    """A matrix declared euclidean but asymmetric is caught at solve time."""
    meta = {**toy_cvrp_instance.metadata.model_dump(mode="json"), "metric_variant": "euclidean"}
    asym = toy_cvrp_instance.model_copy(update={"arc_costs": [[0, 1, 3], [2, 0, 1], [3, 1, 0]], "metadata": meta})
    with pytest.raises(InstanceNotSupportedError):
        run_solver(ExternalSolver(FAKE_X), _write(asym, tmp_path), time_limit_s=1)


@pytest.mark.parametrize(
    ("mode", "status", "message"),
    [
        ("crash", "failed", "no solution file"),
        ("no-output", "failed", "no solution file"),
        ("garbage", "failed", "unreadable solution file"),
    ],
)
def test_solver_failures_are_results_not_exceptions(collection: Path, monkeypatch, mode, status, message) -> None:
    _env(monkeypatch, FAKE_MODE=mode)
    solved = run_solver(ExternalSolver(FAKE_LKH), _variant(collection, "CVRP", "fastest"), time_limit_s=5)
    assert solved.result.status == status and message in solved.result.error
    assert not solved.valid


def test_a_run_without_a_solution_reports_what_the_solver_said(collection: Path, monkeypatch) -> None:
    """The work directory and its log are gone by the time the error is read: the error carries the reason."""
    _env(monkeypatch, FAKE_MODE="crash")
    solved = run_solver(ExternalSolver(FAKE_LKH), _variant(collection, "CVRP", "fastest"), time_limit_s=5)
    assert solved.result.status == "failed"
    assert "no solution file (returncode 3)" in solved.result.error
    assert "the solver's output ends with: fake solver: mode=crash" in solved.result.error


def test_zero_based_ids_are_read_when_the_descriptor_declares_them(collection: Path, monkeypatch) -> None:
    _env(monkeypatch, FAKE_MODE="zero-based")
    path = _variant(collection, "CVRP", "euclidean")
    solved = run_solver(ExternalSolver(FAKE_X.with_overrides(id_convention="zero-based")), path, time_limit_s=5)
    assert solved.valid and solved.result.provenance["solution_ids"] == "zero-based"
    # Undeclared, the file is read the way CVRPLIB numbers stops (1..n, 0 is the depot): refused, with the key to set.
    refused = run_solver(ExternalSolver(FAKE_X), path, time_limit_s=5)
    assert refused.result.status == "failed" and not refused.result.routes
    assert "never visited" in refused.result.error
    assert 'id_convention = "zero-based" (solvers.fake-x' in refused.result.error


def test_an_incomplete_answer_is_never_completed(collection: Path, monkeypatch) -> None:
    """Customers from 1, the depot written as 0 once, the last customer left out: the ids cover 0..n-1."""
    _env(monkeypatch, FAKE_MODE="depot-and-missing")
    path = _variant(collection, "CVRP", "euclidean")
    solved = run_solver(ExternalSolver(FAKE_X), path, time_limit_s=5)
    assert solved.result.status == "failed" and not solved.result.routes
    assert "never visited" in solved.result.error
    assert solved.result.provenance["solution_ids"] == "one-based"
    # "auto" is a choice of the descriptor. It reads this file as a complete zero-based one, which is
    # why it is not the default: these are routes that the solver never produced.
    guessed = run_solver(ExternalSolver(FAKE_X.with_overrides(id_convention="auto")), path, time_limit_s=5)
    assert guessed.valid and guessed.result.provenance["solution_ids"] == "zero-based"


def test_the_builtin_solvers_declare_cvrplib_numbering() -> None:
    assert {descriptor.id_convention for descriptor in BUILTIN_DESCRIPTORS.values()} == {"one-based"}


def test_a_wrong_reported_cost_is_flagged_and_ignored(collection: Path, monkeypatch) -> None:
    _env(monkeypatch, FAKE_MODE="wrong-cost")
    solved = run_solver(ExternalSolver(FAKE_LKH), _variant(collection, "CVRP", "fastest"), time_limit_s=5)
    assert solved.valid
    assert solved.result.provenance["reported_cost_matches_exported_model"] is False
    assert solved.cost == pytest.approx(solved.result.solver_cost - 250.0)  # 1,000 units of 1/4
    # The routes are kept (the checker priced them), and the result says that the solver's number is another one.
    assert solved.result.status == "feasible"
    raw = int(solved.result.solver_report["value"])
    assert f"reported {raw} solver units" in solved.result.error
    assert f"Its routes cost {raw - 1000} units in the exported matrix" in solved.result.error


def test_module_invocation_does_not_credit_unused_script(tmp_path, collection):
    unused = tmp_path / "unused.py"
    unused.write_text("raise AssertionError()")
    desc = FAKE_LKH.with_overrides(executable=str(unused), extra_args=())
    solved = run_solver(ExternalSolver(desc), _variant(collection, "CVRP", "fastest"), time_limit_s=5)
    assert solved.valid
    assert solved.result.provenance["executable_sha256"] is None
    assert "executable_sha256" not in solved.bks_metadata()


def test_integer_report_uses_written_digits_and_checks_actual_export(tmp_path, toy_cvrp_instance):
    from mamut_routing_lib.solutions import parse_lkh_mtsp_solution, parse_solution_text
    from mamut_routing_lib.solvers.external.adapter import _exported_route_cost

    raw = 9007199254740993
    for text in [f"Route #1: 1\nCost {raw}.0", f'{{"routes":[[1]],"cost":{raw}.0}}']:
        _, cost = parse_solution_text(text, exact_report=True)
        assert type(cost) is int and cost == raw
    _, _, cost = parse_lkh_mtsp_solution(f"instance, Cost: 0_{raw}\n1 2 1 (#1) Cost: 0", exact_report=True)
    assert type(cost) is int and cost == raw
    path = tmp_path / "problem.vrp"
    path.write_text(f"EDGE_WEIGHT_SECTION\n0 {raw - 1}\n1 0\nEOF\n")
    assert _exported_route_cost(path, [[1]], 2) == raw

    script = tmp_path / "solver.py"
    script.write_text("import sys\nfrom pathlib import Path\n"
                      "Path(sys.argv[1]).write_text('Route #1: 1 2\\nCost 14.00000000000000001\\n')\n")
    desc = FAKE_LKH.with_overrides(executable=str(script), argv=("{python}", "{executable}", "{solution}"),
                                   output_format="cvrplib-sol")
    solved = run_solver(ExternalSolver(desc), _write(toy_cvrp_instance, tmp_path), time_limit_s=5)
    assert solved.valid
    assert solved.result.provenance["reported_cost_matches_exported_model"] is False
    report = solved.result.solver_report
    assert report["encoding"] == "decimal-text"
    assert report["value"] == "14.00000000000000001" and report["value"] in solved.result.error


def test_missing_report_still_checks_routes_without_an_export_comparison(tmp_path, toy_cvrp_instance):
    script = tmp_path / "routes_only.py"
    script.write_text("import sys\nfrom pathlib import Path\n"
                      "Path(sys.argv[1]).write_text('Route #1: 1 2')\n")
    desc = FAKE_LKH.with_overrides(executable=str(script), argv=("{python}", "{executable}", "{solution}"),
                                   output_format="cvrplib-sol")
    solved = run_solver(ExternalSolver(desc), _write(toy_cvrp_instance, tmp_path), time_limit_s=5)
    assert solved.valid and solved.cost is not None
    assert solved.result.solver_report is None and solved.result.solver_cost is None
    assert "solver_report" not in solved.bks_metadata()
    assert "reported_cost_matches_exported_model" not in solved.result.provenance


def test_unrepresentable_window_is_refused_before_launch(tmp_path, toy_vrptw_instance):
    from mamut_routing_lib.solvers.external.scaling import Limits

    data = toy_vrptw_instance.model_copy(update={"time_windows": [(0, 100), (5, 6), (0, 50)]})
    desc = FAKE_LKH.with_overrides(limits=Limits(max_time_value=20))
    with pytest.raises(InstanceNotSupportedError, match="empties the time window at vertex 1"):
        run_solver(ExternalSolver(desc), _write(data, tmp_path), workdir=tmp_path / "run", time_limit_s=5)
    assert not (tmp_path / "run" / "solver.log").exists()


def test_python_descriptor_preserves_positions_and_rejects_unknown_ids():
    from dataclasses import fields
    from mamut_routing_lib.solutions import SolutionFormatError, normalize_routes

    positional = []
    for field in fields(FAKE_X):
        if field.name == "distance_model":
            break
        if not field.kw_only:
            positional.append(getattr(FAKE_X, field.name))
    desc = ExternalSolverDescriptor(*positional, "nint")
    assert desc.distance_model == "nint" and desc.id_convention == "one-based"
    with pytest.raises(ValueError, match="id_convention"):
        desc.with_overrides(id_convention="typo")
    with pytest.raises(SolutionFormatError, match="id_convention"):
        normalize_routes([[0, 1, 2]], 3, convention="typo")


def test_a_matching_reported_cost_leaves_no_remark(collection: Path) -> None:
    solved = run_solver(ExternalSolver(FAKE_LKH), _variant(collection, "CVRP", "fastest"), time_limit_s=5)
    assert solved.result.provenance["reported_cost_matches_exported_model"] is True and solved.result.error is None


def test_nonzero_exit_with_a_solution_keeps_the_solution(collection: Path, monkeypatch) -> None:
    _env(monkeypatch, FAKE_MODE="nonzero-with-solution")
    solved = run_solver(ExternalSolver(FAKE_X), _variant(collection, "CVRP", "euclidean"), time_limit_s=5)
    assert solved.valid and "exited with code 7" in solved.result.error


def test_timeout_and_cancellation(collection: Path, monkeypatch) -> None:
    _env(monkeypatch, FAKE_MODE="sleep")
    path = _variant(collection, "CVRP", "fastest")
    timed_out = run_solver(ExternalSolver(FAKE_LKH), path, time_limit_s=0.3)
    assert timed_out.result.status == "timeout" and not timed_out.valid

    monitor = SolveMonitor(None, interval_s=0.0)
    timer = threading.Timer(0.3, monitor.request_stop)
    timer.start()
    cancelled = run_solver(ExternalSolver(FAKE_LKH), path, time_limit_s=60, monitor=monitor)
    timer.cancel()
    assert cancelled.result.status == "cancelled" and cancelled.result.stopped_early


def test_live_progress_is_reported_in_instance_units(collection: Path, monkeypatch) -> None:
    _env(monkeypatch, FAKE_MODE="slow", FAKE_SLEEP="0.6")
    ticks = []
    monitor = SolveMonitor(lambda tick: ticks.append(tick) or False, interval_s=0.0)
    solved = run_solver(ExternalSolver(FAKE_X), _variant(collection, "CVRP", "euclidean"), time_limit_s=5, monitor=monitor)
    assert solved.valid
    assert {tick.phase for tick in ticks} >= {"solving"}
    incumbents = [tick.best_cost for tick in ticks if tick.best_cost is not None]
    assert incumbents and min(incumbents) == pytest.approx(solved.cost, abs=1e-3)


def test_keep_artifacts(collection: Path, tmp_path: Path) -> None:
    workdir = tmp_path / "artifacts"
    solved = run_solver(
        ExternalSolver(FAKE_LKH), _variant(collection, "CVRP", "fastest"), time_limit_s=5, workdir=workdir, keep_artifacts=True
    )
    assert solved.valid
    assert (workdir / "problem.vrp").is_file() and (workdir / "problem.par").is_file() and (workdir / "solver.log").is_file()
    assert solved.result.provenance["artifacts_dir"] == str(workdir.resolve())


@pytest.mark.parametrize("descriptor", [FAKE_LKH, FAKE_X], ids=["lkh", "x-format"])
def test_a_reused_workdir_never_hands_back_an_earlier_solution(collection: Path, tmp_path: Path, monkeypatch, descriptor) -> None:
    workdir = tmp_path / "reused"
    path = _variant(collection, "CVRP", "fastest" if descriptor is FAKE_LKH else "euclidean")
    first = run_solver(ExternalSolver(descriptor), path, time_limit_s=5, workdir=workdir, keep_artifacts=True)
    assert first.valid
    _env(monkeypatch, FAKE_MODE="crash")
    crashed = run_solver(ExternalSolver(descriptor), path, time_limit_s=5, workdir=workdir, keep_artifacts=True)
    assert crashed.result.status == "failed" and "no solution file" in crashed.result.error
    assert not crashed.valid and not crashed.result.routes


def test_a_temporary_workdir_is_removed(collection: Path) -> None:
    solved = run_solver(ExternalSolver(FAKE_LKH), _variant(collection, "CVRP", "fastest"), time_limit_s=5)
    assert "artifacts_dir" not in solved.result.provenance


def test_builtins_are_registered_and_explain_missing_executables(monkeypatch) -> None:
    monkeypatch.setenv("PATH", "/nonexistent")
    names = solver_names()
    for name in ("filo2", "hgs-cvrp", "ails2", "lkh3"):
        assert name in names
        availability = get_solver(name).availability()
        assert not availability.available
        assert "solvers.toml" in availability.hint
    assert "patch" in BUILTIN_DESCRIPTORS["ails2"].requires_note


def _executable(tmp_path: Path, name: str) -> Path:
    path = tmp_path / name
    path.write_text("#!/bin/sh\nexit 0\n")
    path.chmod(0o755)
    return path


@pytest.mark.parametrize("relative_path", [".", "/nonexistent:.", "/nonexistent::/also-nonexistent", "tree"])
def test_a_bare_name_is_never_found_through_the_working_directory(tmp_path: Path, monkeypatch, relative_path: str) -> None:
    """A relative PATH entry is the working directory: a file called `filo2` in a benchmark tree is not the solver."""
    tree = tmp_path / "tree"
    tree.mkdir()
    for name in ("filo2", "java"):
        _executable(tree, name)
    monkeypatch.chdir(tmp_path if relative_path == "tree" else tree)
    monkeypatch.setenv("PATH", relative_path.replace(":", os.pathsep))

    found_by_name = ExternalSolver(BUILTIN_DESCRIPTORS["filo2"]).availability()
    assert not found_by_name.available and "only found through a relative PATH entry" in found_by_name.reason
    configured = ExternalSolver(BUILTIN_DESCRIPTORS["filo2"].with_overrides(executable="filo2")).availability()
    assert not configured.available and "'filo2' is not on PATH" in configured.reason
    assert "only found through a relative PATH entry" in configured.reason
    jar = tmp_path / "solver.jar"
    jar.write_bytes(b"jar")
    java = ExternalSolver(BUILTIN_DESCRIPTORS["ails2"].with_overrides(jar=str(jar))).availability()
    assert not java.available and "java not found on PATH" in java.reason


def test_a_bare_name_is_found_in_the_absolute_entries_of_path(tmp_path: Path, monkeypatch) -> None:
    tree, bin_dir = tmp_path / "tree", tmp_path / "bin"
    for folder in (tree, bin_dir):
        folder.mkdir()
        _executable(folder, "filo2")
    monkeypatch.chdir(tree)
    monkeypatch.setenv("PATH", os.pathsep.join([".", str(bin_dir)]))  # the working directory comes first, and is skipped
    availability = ExternalSolver(BUILTIN_DESCRIPTORS["filo2"]).availability()
    assert availability.available and availability.executable == str((bin_dir / "filo2").resolve())


def test_a_configured_executable_never_falls_back_to_another_on_path(tmp_path: Path, monkeypatch) -> None:
    import dataclasses

    on_path = tmp_path / "bin"
    on_path.mkdir()
    _executable(on_path, "hgs")  # an unpatched build somebody left on PATH
    monkeypatch.setenv("PATH", str(on_path))
    builtin = BUILTIN_DESCRIPTORS["hgs-cvrp"]
    assert ExternalSolver(builtin).resolve_executable()[0] == str((on_path / "hgs").resolve())
    typo = ExternalSolver(dataclasses.replace(builtin, executable="hgs-patched"))
    executable, reason = typo.resolve_executable()
    assert executable is None and "'hgs-patched' is not on PATH" in reason
    missing = ExternalSolver(dataclasses.replace(builtin, executable=str(tmp_path / "nowhere" / "hgs")))
    assert missing.resolve_executable()[0] is None
    _executable(on_path, "hgs-patched")
    assert typo.resolve_executable()[0] == str((on_path / "hgs-patched").resolve())


def test_builtin_argv_templates(collection: Path, tmp_path: Path, toy_cvrp_instance) -> None:
    from mamut_routing_lib.artifacts import load_benchmark_instance
    from mamut_routing_lib.solvers.base import SolveRequest

    path = _variant(collection, "CVRP", "euclidean")
    request = SolveRequest(
        instance=load_benchmark_instance(path), instance_path=path, objective=ObjectiveFunction.MONO_COST,
        time_limit_s=12.5, seed=3,
    )
    filo = ExternalSolver(BUILTIN_DESCRIPTORS["filo2"].with_overrides(executable=str(_executable(tmp_path, "filo2"))))
    (tmp_path / "w1").mkdir()
    prepared = filo.prepare(request, tmp_path / "w1")
    argv = filo.build_argv(prepared, request)
    assert argv[-2:] == ["--optimization-seconds", "12"]
    assert prepared.solution.name == "problem.vrp_seed-3.vrp.sol"
    assert prepared.plan.unit == "mm"
    header = prepared.problem.read_text().splitlines()[:6]
    assert header[5] == "CAPACITY : 10" and not any(line.startswith("VEHICLES") for line in header)

    jar = tmp_path / "AILSII.jar"
    jar.write_text("")
    ails = ExternalSolver(BUILTIN_DESCRIPTORS["ails2"].with_overrides(jar=str(jar), java=sys.executable))
    (tmp_path / "w2").mkdir()
    prepared = ails.prepare(request, tmp_path / "w2")
    argv = ails.build_argv(prepared, request)
    assert argv[:4] == [sys.executable, "-Xmx4g", "-XX:+UseSerialGC", "-XX:ActiveProcessorCount=1"]
    assert argv[argv.index("-limit") + 1] == "12.5" and argv[argv.index("-out") + 1] == str(prepared.solution)

    fleet = toy_cvrp_instance.model_copy(update={"num_vehicles": 2})
    fixed = _write(fleet, tmp_path)
    meta = json.loads(fixed.read_text())
    hgs = ExternalSolver(BUILTIN_DESCRIPTORS["hgs-cvrp"].with_overrides(executable=str(_executable(tmp_path, "hgs"))))
    fleet_request = SolveRequest(
        instance=load_benchmark_instance(fixed), instance_path=fixed, objective=ObjectiveFunction.MONO_COST,
        time_limit_s=5, seed=1,
    )
    (tmp_path / "w3").mkdir()
    prepared = hgs.prepare(fleet_request, tmp_path / "w3")
    assert hgs.build_argv(prepared, fleet_request)[-2:] == ["-veh", "2"]
    assert meta["num_vehicles"] == 2


FAKE_MATRIX = FAKE_X.with_overrides(
    name="fake-matrix",
    label="FakeMatrix",
    method="fake-matrix",
    input_format="cvrplib-matrix",
    capabilities=SolverCapabilities(objectives=CVRP_MONO, input="explicit", symmetric_only=False),
    matrix_scales=(1.0, 0.1),
)


def test_full_matrix_solver_takes_asymmetric_road_metrics(collection: Path, toy_cvrp_instance, tmp_path: Path) -> None:
    asym = toy_cvrp_instance.model_copy(update={"arc_costs": [[0, 5, 6], [7, 0, 3], [6, 4, 0]]})
    for path in (_variant(collection, "CVRP", "fastest"), _write(asym, tmp_path)):
        solved = run_solver(ExternalSolver(FAKE_MATRIX), path, time_limit_s=5)
        assert solved.valid, solved.result.error
        assert solved.result.solver_report["encoding"] == "decimal-text"
        assert solved.result.provenance["scale"]["rounding"] == "float"
        assert solved.result.solver_cost == pytest.approx(solved.cost)
        assert "reported_cost_matches_exported_model" not in solved.result.provenance  # float solver: no exact cross-check


def test_builtin_hgs_reads_the_full_matrix(collection: Path, tmp_path: Path, monkeypatch) -> None:
    from mamut_routing_lib.artifacts import load_benchmark_instance
    from mamut_routing_lib.solvers.base import SolveRequest, profile_instance

    hgs = ExternalSolver(BUILTIN_DESCRIPTORS["hgs-cvrp"].with_overrides(executable=str(_executable(tmp_path, "hgs"))))
    path = _variant(collection, "CVRP", "fastest")
    instance = load_benchmark_instance(path)
    assert hgs.supports(profile_instance(instance, path), ObjectiveFunction.MONO_COST).supported
    request = SolveRequest(instance=instance, instance_path=path, objective=ObjectiveFunction.MONO_COST, time_limit_s=5)
    (tmp_path / "w").mkdir()
    prepared = hgs.prepare(request, tmp_path / "w")
    lines = prepared.problem.read_text().splitlines()
    assert "EDGE_WEIGHT_FORMAT : FULL_MATRIX" in lines and lines[lines.index("EDGE_WEIGHT_SECTION") + 1] == "0 120.5 240.25"
    assert prepared.plan.factor == 1.0 and prepared.plan.exact
    argv = hgs.build_argv(prepared, request)
    assert argv[1:3] == [str(prepared.problem), str(prepared.solution)] and "-round" in argv
    monkeypatch.setenv("PATH", "/nonexistent")
    missing = ExternalSolver(BUILTIN_DESCRIPTORS["hgs-cvrp"]).availability()
    assert not missing.available and "hgs-cvrp-explicit-matrix.patch" in missing.note
    assert "hgs-cvrp-explicit-matrix.patch" in missing.describe()  # what `solve` prints


def test_a_cancel_poll_is_seen_between_steps_not_only_at_ticks(collection: Path, tmp_path: Path, monkeypatch) -> None:
    """The GUI cancels through a flag: a cancel while a large input is written must not launch the solver."""
    path = _variant(collection, "CVRP", "fastest")
    flag = {"cancelled": True}
    early = tmp_path / "early"
    solved = run_solver(
        ExternalSolver(FAKE_LKH), path, time_limit_s=60, workdir=early, keep_artifacts=True,
        monitor=SolveMonitor(None, interval_s=3600.0, cancelled=lambda: flag["cancelled"]),
    )
    assert solved.result.status == "cancelled" and not (early / "problem.vrp").exists()

    flag["cancelled"] = False
    original = ExternalSolver.prepare

    def prepare(self, request, workdir):  # the user cancels while the input is being written
        prepared = original(self, request, workdir)
        flag["cancelled"] = True
        return prepared

    monkeypatch.setattr(ExternalSolver, "prepare", prepare)
    late = tmp_path / "late"
    solved = run_solver(
        ExternalSolver(FAKE_LKH), path, time_limit_s=60, workdir=late, keep_artifacts=True,
        monitor=SolveMonitor(None, interval_s=3600.0, cancelled=lambda: flag["cancelled"]),
    )
    assert solved.result.status == "cancelled" and (late / "problem.vrp").exists()
    assert not (late / "solver.log").exists()  # the solver never started


def test_lkh_extra_args_go_to_the_parameter_file_whatever_the_argv(collection: Path, tmp_path: Path) -> None:
    """A wrapped command (taskset, a launcher script) still gets its extra parameter lines."""
    from mamut_routing_lib.artifacts import load_benchmark_instance
    from mamut_routing_lib.solvers.base import SolveRequest

    path = _variant(collection, "CVRP", "fastest")
    request = SolveRequest(
        instance=load_benchmark_instance(path), instance_path=path, objective=ObjectiveFunction.MONO_COST, time_limit_s=5,
    )
    for argv in (("{executable}", "{params}"), ("taskset", "-c", "0", "{executable}", "{params}")):
        solver = ExternalSolver(
            BUILTIN_DESCRIPTORS["lkh3"].with_overrides(
                executable=str(_executable(tmp_path, "LKH")), argv=argv, extra_args=("RUNS = 10", "POPULATION_SIZE = {5}")
            )
        )
        workdir = tmp_path / f"w{len(argv)}"
        workdir.mkdir()
        prepared = solver.prepare(request, workdir)
        assert prepared.params.read_text().splitlines()[-2:] == ["RUNS = 10", "POPULATION_SIZE = {5}"]
        assert solver.build_argv(prepared, request)[-1] == str(prepared.params)  # no stray command-line token


def test_one_solve_reads_the_distance_matrix_once(collection: Path, monkeypatch) -> None:
    """The adapter's input, the check and the store share the hydrated instance."""
    from mamut_routing_lib import distances
    from mamut_routing_lib.solutions import submit_bks

    reads: list[Path] = []
    original = distances.load_instance_distances

    def counting(path, *args, **kwargs):
        reads.append(Path(path))
        return original(path, *args, **kwargs)

    monkeypatch.setattr(distances, "load_instance_distances", counting)
    path = _variant(collection, "CVRP", "fastest")
    solved = run_solver(ExternalSolver(FAKE_LKH), path, time_limit_s=5)
    assert solved.valid and solved.checkable is not None
    update = submit_bks(path, solved.result.routes, authors="Ada", checkable=solved.checkable)
    assert update.action == "created" and len(reads) == 1

    reads.clear()
    pytest.importorskip("pyvrp")
    assert run_solver("pyvrp", path, time_limit_s=1).valid
    assert len(reads) == 1


def test_an_lkh_descriptor_cannot_contradict_the_run_it_records() -> None:
    """LKH-3 keeps the last occurrence of a parameter: an extra `SEED = 1` would run another seed than the result says."""
    from mamut_routing_lib.solvers.external.problem import lkh_parameter_key, render_lkh_params

    assert [lkh_parameter_key(line) for line in ("SEED = 1", "  seed=1", "= Time_Limit 9", "# SEED = 1", "", "RUNS = 10")] == [
        "SEED", "SEED", "TIME_LIMIT", "", "", "RUNS",
    ]
    for line in ("SEED = 1", "TIME_LIMIT = 9999", "precision=10", "PROBLEM_FILE = x.vrp", "MTSP_SOLUTION_FILE = x.sol"):
        with pytest.raises(ValueError, match="the run would not be the one that its result records"):
            FAKE_LKH.with_overrides(extra_args=(line,))
        with pytest.raises(ValueError, match="sets "):
            list(render_lkh_params(problem=Path("p.vrp"), solution=Path("s.sol"), seed=7, time_limit_s=5, extra=(line,)))
    assert FAKE_LKH.with_overrides(extra_args=("RUNS = 10",)).extra_args == ("RUNS = 10",)
    # For any other input format, extra_args are command-line tokens: nothing of LKH-3 applies.
    assert FAKE_X.with_overrides(extra_args=("SEED = 1",)).extra_args == ("SEED = 1",)
    lines = list(render_lkh_params(problem=Path("p.vrp"), solution=Path("s.sol"), seed=7, time_limit_s=5, extra=("RUNS = 10",)))
    assert lines[-1] == "RUNS = 10" and "SEED = 7" in lines and "TIME_LIMIT = 5.0" in lines
