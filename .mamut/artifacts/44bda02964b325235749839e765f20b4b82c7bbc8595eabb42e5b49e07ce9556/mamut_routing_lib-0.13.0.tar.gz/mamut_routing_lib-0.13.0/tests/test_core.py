from __future__ import annotations

from pathlib import Path

from mamut_routing_lib.sidecars import CollectionMarker, save_collection_marker

from mamut_routing_lib import (
    BenchmarkInstanceVRPTW,
    BenchmarkInstanceCVRP,
    BenchmarkSolution,
    DEFAULT_BKS_AUTHORS,
    ObjectiveFunction,
    check_cvrp_solution,
    check_vrptw_solution,
    compute_solution_cost,
    create_bks_from_solution,
    discover_benchmark_instances,
    save_bks_if_improved,
    save_json_to_file,
)


def make_cvrp_instance() -> BenchmarkInstanceCVRP:
    return BenchmarkInstanceCVRP(
        instance_name="poryos-n2-testcvrp",
        instance_origin="OsmCvrpGen",
        benchmark_name="Poryos2026",
        num_customers=2,
        vehicle_capacity=10,
        coordinates=[(0.0, 0.0), (1.0, 1.0), (2.0, 2.0)],
        demands=[0, 3, 4],
        depot=0,
        arc_costs=[
            [0, 5, 6],
            [5, 0, 3],
            [6, 3, 0],
        ],
        metadata={
            "authors": "Florian Rascoussier (0nyr) and Adrien Pichon (Anzury)",
            "generated_at": "2026-04-23T00:00:00",
            "problem_type": "CVRP",
            "metric_variant": "fastest",
            "place_slug": "testville",
            "source_base_name": "test",
            "source_city": "Testville",
            "source_seed": 1,
            "source_folder": "test",
            "num_vehicles_lb": 1,
            "artifact_paths": {
                "vrp_json": "benchmarks/CVRP/Poryos2026/fastest/testville/n=2/poryos-n2-testcvrp/poryos-n2-testcvrp.vrp.json",
                "vrp": "benchmarks/CVRP/Poryos2026/fastest/testville/n=2/poryos-n2-testcvrp/poryos-n2-testcvrp.vrp",
                "meta": "benchmarks/CVRP/Poryos2026/sidecars/testville/n=2/poryos-n2-testcvrp/poryos-n2-testcvrp.meta.json",
                "manifest": "benchmarks/CVRP/Poryos2026/sidecars/testville/n=2/poryos-n2-testcvrp/poryos-n2-testcvrp.manifest.json",
            },
        },
    )


def make_vrptw_instance() -> BenchmarkInstanceVRPTW:
    return BenchmarkInstanceVRPTW(
        instance_name="poryos-n2-testvrptw",
        instance_origin="OsmCvrpGen",
        benchmark_name="Poryos2026",
        num_customers=2,
        vehicle_capacity=10,
        coordinates=[(0.0, 0.0), (1.0, 1.0), (2.0, 2.0)],
        demands=[0, 3, 4],
        depot=0,
        arc_costs=[
            [0, 5, 6],
            [5, 0, 3],
            [6, 3, 0],
        ],
        service_times=[0, 2, 2],
        time_windows=[(0, 100), (0, 50), (0, 50)],
        metadata={
            "authors": "Florian Rascoussier (0nyr) and Adrien Pichon (Anzury)",
            "generated_at": "2026-04-23T00:00:00",
            "problem_type": "VRPTW",
            "metric_variant": "fastest",
            "place_slug": "testville",
            "source_base_name": "test",
            "source_city": "Testville",
            "source_seed": 1,
            "source_folder": "test",
            "num_vehicles_lb": 1,
            "artifact_paths": {
                "vrp_json": "benchmarks/VRPTW/Poryos2026/fastest/testville/n=2/poryos-n2-testvrptw/poryos-n2-testvrptw.vrp.json",
                "vrp": "benchmarks/VRPTW/Poryos2026/fastest/testville/n=2/poryos-n2-testvrptw/poryos-n2-testvrptw.vrp",
                "meta": "benchmarks/VRPTW/Poryos2026/sidecars/testville/n=2/poryos-n2-testvrptw/poryos-n2-testvrptw.meta.json",
                "manifest": "benchmarks/VRPTW/Poryos2026/sidecars/testville/n=2/poryos-n2-testvrptw/poryos-n2-testvrptw.manifest.json",
            },
        },
    )


def test_discover_benchmark_instances_and_problem_specific_layout(tmp_path: Path) -> None:
    benchmark_root = tmp_path / "benchmarks"
    collection = benchmark_root / "Poryos2026"
    save_collection_marker(CollectionMarker(family="Poryos2026"), collection)
    cvrp_path = collection / "CVRP" / "fastest" / "testville" / "n=2" / "poryos-n2-testcvrp" / "poryos-n2-testcvrp.vrp.json"
    vrptw_path = collection / "VRPTW" / "euclidean" / "testville" / "n=2" / "poryos-n2-testvrptw" / "poryos-n2-testvrptw.vrp.json"
    save_json_to_file(make_cvrp_instance().model_dump(mode="json"), cvrp_path)
    save_json_to_file(make_vrptw_instance().model_dump(mode="json"), vrptw_path)

    discovered = discover_benchmark_instances(benchmark_root, benchmark_names=["Poryos2026"])

    assert len(discovered) == 2
    assert {item.problem_type.value for item in discovered} == {"CVRP", "VRPTW"}
    assert {item.instance_id for item in discovered} == {
        "cvrp-poryos2026-fastest-testville-n2-poryos-n2-testcvrp",
        "vrptw-poryos2026-euclidean-testville-n2-poryos-n2-testvrptw",
    }
    assert {item.instance_name for item in discovered} == {"poryos-n2-testcvrp", "poryos-n2-testvrptw"}


def test_cvrp_and_vrptw_checkers_validate_feasible_solutions() -> None:
    cvrp_solution = BenchmarkSolution(instance_name="poryos-n2-testcvrp", routes=[[1, 2]], cost=14)
    vrptw_solution = BenchmarkSolution(instance_name="poryos-n2-testvrptw", routes=[[1, 2]], cost=14)

    cvrp_check = check_cvrp_solution(make_cvrp_instance(), cvrp_solution)
    vrptw_check = check_vrptw_solution(make_vrptw_instance(), vrptw_solution)

    assert cvrp_check.is_valid()
    assert vrptw_check.is_valid()
    assert cvrp_check.routing_cost == 14
    assert vrptw_check.routing_cost == 14


def test_bks_replacement_only_happens_on_strict_improvement(tmp_path: Path) -> None:
    instance = make_cvrp_instance()
    instance_path = tmp_path / "poryos-n2-testcvrp.vrp.json"
    save_json_to_file(instance.model_dump(mode="json"), instance_path)

    first_bks = create_bks_from_solution(
        instance,
        BenchmarkSolution(instance_name=instance.instance_name, routes=[[1, 2]], cost=14),
        ObjectiveFunction.MONO_COST,
        authors=DEFAULT_BKS_AUTHORS,
    )
    created = save_bks_if_improved(instance, first_bks, instance_path)
    assert created.action == "created"
    assert created.path.name == "poryos-n2-testcvrp.bks.MonoCost.json"
    assert first_bks.metadata["authors"] == DEFAULT_BKS_AUTHORS

    worse_bks = create_bks_from_solution(
        instance,
        BenchmarkSolution(instance_name=instance.instance_name, routes=[[1], [2]], cost=22),
        ObjectiveFunction.MONO_COST,
        authors=DEFAULT_BKS_AUTHORS,
    )
    kept = save_bks_if_improved(instance, worse_bks, instance_path)
    assert kept.action == "kept_existing"


def test_compute_solution_cost_accepts_raw_list_of_routes() -> None:
    instance = make_cvrp_instance()
    raw_routes = [[1, 2]]

    cost = compute_solution_cost(instance, raw_routes)

    # depot(0) -> 1 (5) -> 2 (3) -> depot (6) = 14
    assert cost == 14


def test_create_bks_from_solution_requires_authors_metadata() -> None:
    instance = make_cvrp_instance()

    try:
        create_bks_from_solution(
            instance,
            BenchmarkSolution(instance_name=instance.instance_name, routes=[[1, 2]], cost=14),
            ObjectiveFunction.MONO_COST,
        )
    except TypeError:
        pass
    else:
        raise AssertionError("create_bks_from_solution should require authors")


def test_valid_check_result_carries_a_route_count_and_a_cost_unless_it_overflows() -> None:
    import pytest
    from pydantic import ValidationError

    from mamut_routing_lib.checker import SolutionCheckResult
    from mamut_routing_lib.enums import SolutionCheckStatus

    assert SolutionCheckResult.make_valid(routing_cost=14, num_routes=0).num_routes == 0
    overflow = {"cost": None, "display_overflow": True}
    held = SolutionCheckResult(status=SolutionCheckStatus.VALID, routing_cost=None, num_routes=1, exact_evaluation=overflow)
    assert held.routing_cost is None
    for fields in (dict(routing_cost=14, num_routes=None), dict(routing_cost=14, num_routes=-1),
                   dict(routing_cost=None, num_routes=1),
                   dict(routing_cost=None, num_routes=1, exact_evaluation={"display_overflow": False}),
                   dict(routing_cost=14, num_routes=1, exact_evaluation=overflow)):
        with pytest.raises(ValidationError, match="valid result"):
            SolutionCheckResult(status=SolutionCheckStatus.VALID, **fields)
    rejected = SolutionCheckResult.make_invalid(SolutionCheckStatus.NOT_ALL_CUSTOMERS_SERVED, "missing")
    assert rejected.routing_cost is None and rejected.num_routes is None


def test_checker_raises_on_a_solution_for_another_instance() -> None:
    import pytest

    instance = make_cvrp_instance()
    other = BenchmarkSolution(instance_name="another-instance", routes=[[1, 2]])
    with pytest.raises(ValueError, match="another-instance"):
        check_cvrp_solution(instance, other)


def test_valid_display_is_nonnegative_finite_and_normalizes_signed_zero() -> None:
    import json
    from math import copysign
    import pytest

    from mamut_routing_lib.checker import SolutionCheckResult

    for cost in (-1, float("nan"), float("inf"), -float("inf"), 10**400):
        record = {"status": "valid", "num_routes": 1, "routing_cost": cost}
        with pytest.raises(ValueError, match="finite nonnegative"):
            SolutionCheckResult.model_validate(record)
        with pytest.raises(ValueError, match="finite nonnegative"):
            SolutionCheckResult.model_validate_json(json.dumps(record))
    record = {"status": "valid", "num_routes": 1, "routing_cost": -0.0}
    assert copysign(1.0, SolutionCheckResult.model_validate(record).routing_cost) == 1.0
    assert copysign(1.0, SolutionCheckResult.model_validate_json(json.dumps(record)).routing_cost) == 1.0


def test_canonical_route_order_validates_its_routes() -> None:
    import pytest

    from mamut_routing_lib.checker import canonical_route_order

    assert canonical_route_order(iter([[2], [1]])) == [[1], [2]]

    assert canonical_route_order([[3, 4], [1, 2]]) == [[1, 2], [3, 4]]
    assert canonical_route_order([]) == []
    for routes in ([[]], [[0, 1]], [[-1]], [[1.0]], [[True]], [["1"]], [[1, 2], [2, 3]], [[1, 1]], [None]):
        with pytest.raises(ValueError, match="canonical_route_order"):
            canonical_route_order(routes)
