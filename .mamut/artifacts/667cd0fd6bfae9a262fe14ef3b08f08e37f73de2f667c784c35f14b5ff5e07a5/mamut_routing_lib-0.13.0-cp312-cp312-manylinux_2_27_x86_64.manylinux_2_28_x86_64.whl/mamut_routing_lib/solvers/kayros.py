"""KAYROS as a registry solver (``kayros``): time-dependent TDVRP / TDVRPTW with Duration or FleetCostDuration.

KAYROS is a separate package (``pip install kayros``, or the tools'
``[kayros]`` extra) that implements the lib's TD checker contract. Its search is
one native call whose only way back into Python is the ``on_incumbent`` hook: a
stop request raised from the hook is not seen once the search stops improving,
which can be the rest of the time limit.

The adapter therefore runs each solve in a child Python process
(``solvers._kayros_worker``) through the external-solver process runner: its own
process group, a hard timeout, and a stop request (the monitor, Ctrl-C, a GUI
cancel) that kills the process within a poll. The worker saves every incumbent
before reporting it, so a stopped solve still returns its last incumbent's
routes. So does a solve whose worker dies without a result -- the system kills
a process that runs out of memory, and native code can crash: the run then
ends as ``feasible`` with ``stopped_early``, its ``error`` says how the worker
ended, and the provenance has ``recovered_from_checkpoint``. An error that the
worker reports itself stays a failed result. The routes are re-checked by the
lib's TD checker afterwards (``solvers.run.run_solver``), like every other
solver's.
"""

from __future__ import annotations

import importlib.util
import json
import math
import os
import shutil
import signal
import sys
import tempfile
import time
from fractions import Fraction
from pathlib import Path
from typing import Any

from mamut_routing_lib.enums import ObjectiveFunction, ProblemType
from mamut_routing_lib.solvers.base import (
    Availability,
    InstanceProfile,
    SolveMonitor,
    SolveRequest,
    SolveResult,
    SolverCapabilities,
    Support,
    capability_support,
)
from mamut_routing_lib.solvers.provenance import declared_requirement, environment, lib_version, package_version, satisfies
from mamut_routing_lib.solvers.report import make_solver_report

__all__ = ["KayrosSolver"]

CHECKPOINT_FILE = "kayros-incumbent.json"
RESULT_FILE = "kayros-result.json"
LOG_FILE = "kayros.log"
WORKER_MODULE = "mamut_routing_lib.solvers._kayros_worker"
#: The worker's progress lines (``_kayros_worker.save_incumbent``).
PROGRESS_PATTERN = r"^incumbent cost=(?P<cost>\S+) iterations=(?P<iterations>\d+)$"
#: KAYROS stops at its time limit by itself; the hard timeout is only there for a process that
#: never returns. It leaves room for what the limit does not cover: loading a large instance's
#: travel-time functions before the search, and the final check after it.
HARD_TIMEOUT_GRACE_S = 600.0

_TD_OBJECTIVES = frozenset({ObjectiveFunction.DURATION, ObjectiveFunction.FLEET_COST_DURATION})
_CAPABILITIES = SolverCapabilities(
    objectives={ProblemType.TDVRP: _TD_OBJECTIVES, ProblemType.TDVRPTW: _TD_OBJECTIVES},
    input="model",
    symmetric_only=False,
    fleet_limit=True,
    warm_start=False,
    live_progress="incumbent",
    cancellable=True,
    in_process=False,
)


def _read_json(path: Path) -> dict[str, Any] | None:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return payload if isinstance(payload, dict) else None


def _routes(payload: dict[str, Any] | None) -> list[list[int]]:
    return [[int(stop) for stop in route] for route in (payload or {}).get("routes") or []]


def _objective_report(objective: str, value: float | None) -> dict[str, Any] | None:
    if value is None or not math.isfinite(value):
        return None
    name = "total-route-duration" if objective == ObjectiveFunction.DURATION.value else "fleet-cost-duration"
    return make_solver_report(name, float(value), encoding="binary64", unit=Fraction(1))


def _how_it_ended(returncode: int | None) -> str:
    """``exited with code 1``, or ``was killed by SIGKILL`` for the negative code of a signal."""
    if returncode is None or returncode >= 0:
        return f"exited with code {returncode}"
    try:
        name = signal.Signals(-returncode).name
    except ValueError:
        name = f"signal {-returncode}"
    # The kernel ends a process that runs out of memory with SIGKILL, and nothing else says so.
    return f"was killed by {name}" + (" (the system does this to a process that runs out of memory)" if name == "SIGKILL" else "")


class KayrosSolver:
    """KAYROS for the Duration and FleetCostDuration objectives on time-dependent instances."""

    name = "kayros"
    label = "KAYROS"
    capabilities = _CAPABILITIES

    def availability(self) -> Availability:
        try:
            spec = importlib.util.find_spec("kayros")
        except (ValueError, ImportError):
            spec = None
        if spec is None:
            return Availability(
                False,
                reason="the kayros package is not installed",
                hint="pip install kayros (a release whose mamut-routing-lib requirement admits this version)",
            )
        return Availability(True, version=package_version("kayros"), note=_requirement_note())

    def supports(self, profile: InstanceProfile, objective: ObjectiveFunction) -> Support:
        support = capability_support(self.capabilities, profile, objective, solver_label=self.label)
        if support.supported and objective is ObjectiveFunction.FLEET_COST_DURATION and not profile.has_fleet_fixed_cost:
            return Support.refuse("FleetCostDuration requires the instance to specify fleet_fixed_cost")
        return support

    def solve(self, request: SolveRequest, monitor: SolveMonitor | None = None) -> SolveResult:
        from mamut_routing_lib.solvers.external.process import run_process

        started = time.perf_counter()
        version = package_version("kayros")
        provenance: dict[str, Any] = {**environment(), "kayros_version": version}
        requirement = declared_requirement("kayros", "mamut-routing-lib")
        if requirement is not None:
            provenance["kayros_requires_lib"] = requirement
            provenance["kayros_requirement_met"] = satisfies(lib_version(), requirement)
        base = dict(
            solver=self.name,
            method="kayros",
            problem_type=type(request.instance).__name__,
            objective_function=request.objective.value,
            instance_id=str(getattr(request.instance, "instance_name", "")),
            seed=int(request.seed),
            time_limit_s=float(request.time_limit_s),
            solver_version=version,
            provenance=provenance,
        )
        if request.instance_path is None:
            return SolveResult(**base, wall_time=0.0, status="failed", error="KAYROS reads the instance from its file: no instance path")
        if monitor is not None:
            if monitor.stop_requested:  # cancelled before anything started
                return SolveResult(**base, wall_time=time.perf_counter() - started, status="cancelled", stopped_early=True)
            monitor.phase("solving")
        own_workdir = request.workdir is None
        workdir = Path(request.workdir or tempfile.mkdtemp(prefix="mamut-kayros-")).resolve()
        workdir.mkdir(parents=True, exist_ok=True)
        checkpoint, result_file = workdir / CHECKPOINT_FILE, workdir / RESULT_FILE
        try:
            # Files left by an earlier run in a reused workdir must never be read as this run's answer.
            checkpoint.unlink(missing_ok=True)
            result_file.unlink(missing_ok=True)
            grace = max(HARD_TIMEOUT_GRACE_S, float(request.time_limit_s))
            outcome = run_process(
                [
                    sys.executable,
                    "-P",  # the work directory must not shadow the library or kayros
                    "-m",
                    WORKER_MODULE,
                    str(Path(request.instance_path).resolve()),
                    "--time-limit",
                    repr(float(request.time_limit_s)),
                    "--objective",
                    request.objective.value,
                    "--seed",
                    str(int(request.seed)),
                    "--checkpoint",
                    str(checkpoint),
                    "--result",
                    str(result_file),
                ],
                cwd=workdir,
                log_path=workdir / LOG_FILE,
                time_limit_s=float(request.time_limit_s),
                grace_s=grace,
                env=_worker_environment(),
                monitor=monitor,
                progress_pattern=PROGRESS_PATTERN,
            )
            provenance.update(
                returncode=outcome.returncode,
                termination=outcome.termination,
                hard_timeout_s=float(request.time_limit_s) + grace,
            )
            result = _read_json(result_file)
            if result is not None and result.get("lib_path"):
                # The worker is another interpreter: record which library it ran, and whether it is this one.
                provenance["worker_lib_version"] = result.get("lib_version")
                provenance["worker_lib_is_parent_lib"] = Path(str(result["lib_path"])) == _LIB_PACKAGE_DIR
            return self._result(base, outcome, result, _read_json(checkpoint), time.perf_counter() - started)
        finally:
            if own_workdir and not request.keep_artifacts:
                shutil.rmtree(workdir, ignore_errors=True)
            else:
                provenance["artifacts_dir"] = str(workdir)

    @staticmethod
    def _result(
        base: dict[str, Any],
        outcome: Any,
        result: dict[str, Any] | None,
        incumbent: dict[str, Any] | None,
        wall_time: float,
    ) -> SolveResult:
        if outcome.termination == "error":
            return SolveResult(**base, wall_time=wall_time, status="failed", error=outcome.error)
        if result is not None and result.get("ok"):
            # A stop request that lands as the worker finishes still gets the finished solution.
            routes = _routes(result)
            stopped = outcome.termination == "cancelled"
            return SolveResult(
                **base,
                wall_time=wall_time,
                status="cancelled" if stopped else ("feasible" if routes else "infeasible"),
                routes=routes,
                solver_report=_objective_report(base["objective_function"], result.get("cost")) if routes else None,
                stopped_early=stopped,
                metadata={
                    "status": result.get("status"),
                    "iterations": result.get("iterations"),
                    "route_durations": list(result.get("route_durations") or []),
                },
            )
        # Whatever follows has no finished solution: the last incumbent that the worker saved is the answer.
        routes = _routes(incumbent)
        common = dict(
            **base,
            wall_time=wall_time,
            routes=routes,
            solver_report=_objective_report(base["objective_function"], incumbent.get("value")) if routes else None,
            metadata={"iterations": (incumbent or {}).get("iteration")},
        )
        if outcome.termination == "exited":
            ended = _how_it_ended(outcome.returncode)
            if result is None and common["routes"]:
                # The worker died without a word (out of memory, a crash in native code). The run is
                # not `failed`: a failed result has no routes for the caller, and these are checked.
                base["provenance"]["recovered_from_checkpoint"] = True
                return SolveResult(
                    **common,
                    status="feasible",
                    stopped_early=True,
                    error=f"the KAYROS worker {ended} before it returned a result: these are the routes of the last incumbent it saved",
                )
            error = (result or {}).get("error")
            if not error:
                lines = [line.strip() for line in outcome.log_tail.splitlines() if line.strip()][-3:]
                error = f"KAYROS {ended} and left no result" + (f": {' | '.join(lines)}" if lines else "")
            return SolveResult(**base, wall_time=wall_time, status="failed", error=str(error))
        # Stopped on request, or killed at the hard timeout.
        if outcome.termination == "cancelled":
            return SolveResult(**common, status="cancelled", stopped_early=True)
        return SolveResult(**common, status="timeout", error="KAYROS did not return by its time limit and was stopped at the hard timeout")


def _requirement_note() -> str | None:
    """A warning when the installed KAYROS declares a mamut-routing-lib range that excludes this version."""
    requirement = declared_requirement("kayros", "mamut-routing-lib")
    if requirement is None or satisfies(lib_version(), requirement) is not False:
        return None
    return (
        f"the installed kayros declares mamut-routing-lib{requirement}, and this is mamut-routing-lib "
        f"{lib_version()}: the two were forced together, and KAYROS may price routes under another checker "
        "contract than this library (results are still re-checked here)"
    )


#: The package directory of the library this process runs.
_LIB_PACKAGE_DIR = Path(__file__).resolve().parents[1]


def _worker_environment() -> dict[str, str]:
    """The environment of the worker: the parent's, with an import path that gives it the parent's library.

    The worker runs in the work directory. Relative ``PYTHONPATH`` entries are made absolute against
    the parent's working directory, and the directory that holds this library comes first, so the
    worker cannot pick another installed copy.
    """
    env = dict(os.environ)
    entries = [str(_LIB_PACKAGE_DIR.parent)]
    for entry in env.get("PYTHONPATH", "").split(os.pathsep):
        if entry:
            absolute = str(Path(entry).resolve())
            if absolute not in entries:
                entries.append(absolute)
    env["PYTHONPATH"] = os.pathsep.join(entries)
    return env
