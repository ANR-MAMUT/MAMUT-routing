from __future__ import annotations

import os
from pathlib import Path

import pytest

from mamut_routing_lib.models import BenchmarkInstanceVRPTW, BenchmarkInstanceCVRP


_TOY_METADATA_CVRP = {
    "authors": "Florian Rascoussier (0nyr) and Adrien Pichon (Anzury)",
    "generated_at": "2026-04-23T00:00:00",
    "problem_type": "CVRP",
    "metric_variant": "fastest",
    "place_slug": "testville",
    "source_base_name": "test",
    "source_city": "Testville",
    "source_seed": 1,
    "source_folder": "test",
    "num_vehicles_lb": 1,
    "artifact_paths": {
        "vrp_json": "benchmarks/CVRP/Poryos2026/fastest/testville/n=2/poryos-n2-testcvrp/poryos-n2-testcvrp.vrp.json",
        "vrp": "benchmarks/CVRP/Poryos2026/fastest/testville/n=2/poryos-n2-testcvrp/poryos-n2-testcvrp.vrp",
        "meta": "benchmarks/CVRP/Poryos2026/sidecars/testville/n=2/poryos-n2-testcvrp/poryos-n2-testcvrp.meta.json",
        "manifest": "benchmarks/CVRP/Poryos2026/sidecars/testville/n=2/poryos-n2-testcvrp/poryos-n2-testcvrp.manifest.json",
    },
}

_TOY_METADATA_VRPTW = {
    **_TOY_METADATA_CVRP,
    "problem_type": "VRPTW",
    "artifact_paths": {
        "vrp_json": "benchmarks/VRPTW/Poryos2026/fastest/testville/n=2/poryos-n2-testvrptw/poryos-n2-testvrptw.vrp.json",
        "vrp": "benchmarks/VRPTW/Poryos2026/fastest/testville/n=2/poryos-n2-testvrptw/poryos-n2-testvrptw.vrp",
        "meta": "benchmarks/VRPTW/Poryos2026/sidecars/testville/n=2/poryos-n2-testvrptw/poryos-n2-testvrptw.meta.json",
        "manifest": "benchmarks/VRPTW/Poryos2026/sidecars/testville/n=2/poryos-n2-testvrptw/poryos-n2-testvrptw.manifest.json",
    },
}


@pytest.fixture
def toy_cvrp_instance() -> BenchmarkInstanceCVRP:
    return BenchmarkInstanceCVRP(
        instance_name="poryos-n2-testcvrp",
        instance_origin="OsmCvrpGen",
        benchmark_name="Poryos2026",
        num_customers=2,
        vehicle_capacity=10,
        coordinates=[(0.0, 0.0), (1.0, 1.0), (2.0, 2.0)],
        demands=[0, 3, 4],
        depot=0,
        arc_costs=[
            [0, 5, 6],
            [5, 0, 3],
            [6, 3, 0],
        ],
        metadata=_TOY_METADATA_CVRP,
    )


@pytest.fixture
def toy_vrptw_instance() -> BenchmarkInstanceVRPTW:
    return BenchmarkInstanceVRPTW(
        instance_name="poryos-n2-testvrptw",
        instance_origin="OsmCvrpGen",
        benchmark_name="Poryos2026",
        num_customers=2,
        vehicle_capacity=10,
        coordinates=[(0.0, 0.0), (1.0, 1.0), (2.0, 2.0)],
        demands=[0, 3, 4],
        depot=0,
        arc_costs=[
            [0, 5, 6],
            [5, 0, 3],
            [6, 3, 0],
        ],
        service_times=[0, 2, 2],
        time_windows=[(0, 100), (0, 50), (0, 50)],
        metadata=_TOY_METADATA_VRPTW,
    )


def pytest_configure(config):
    """Make ``PYTHONPATH`` absolute for the whole session.

    Several tests start stand-in solvers as child Python processes in a temporary work
    directory. A relative entry such as ``PYTHONPATH=src`` would not resolve from there,
    and the children would import another installed copy of the library, or none.
    """
    entries = [str(Path(entry).resolve()) for entry in os.environ.get("PYTHONPATH", "").split(os.pathsep) if entry]
    if entries:
        os.environ["PYTHONPATH"] = os.pathsep.join(entries)


@pytest.fixture(autouse=True)
def _isolated_solvers_config(tmp_path_factory, monkeypatch):
    """No test reads the developer's ~/.config/mamut-routing/solvers.toml or $MAMUT_ROUTING_SOLVERS_CONFIG."""
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path_factory.mktemp("xdg-config")))
    monkeypatch.delenv("MAMUT_ROUTING_SOLVERS_CONFIG", raising=False)
    from mamut_routing_lib.solvers import registry

    registry.reload_solvers()
    yield
    registry.reload_solvers()
